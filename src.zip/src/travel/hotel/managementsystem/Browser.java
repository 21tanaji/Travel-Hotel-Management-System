
package travel.hotel.managementsystem;

import javax.swing.*;
import java.awt.event.*;

public class Browser extends JFrame implements ActionListener{
    Browser(){
       JEditorPane j = new JEditorPane(); 
       j.setEditable(false);
       
       try{
           j.setPage("https://www.booking.com");
       }catch(Exception e){
          j.setContentType("text/html");
          j.setText("<html>Could not load, Error 404</html>");
       }
       
       JScrollPane js = new JScrollPane(j);
       getContentPane().add(js);
      
       
       setBounds(450,200,1200,800);
    }
    
    public void actionPerformed(ActionEvent ae){
        this.setVisible(false);
        new Payment().setVisible(true);
    }
    
    public static void main(String[] args) {
        
        new Browser().setVisible(true);
    }
 
}
    
